-- phpMyAdmin SQL Dump
-- version phpStudy 2014
-- http://www.phpmyadmin.net
--
-- 主机: localhost
-- 生成日期: 2018 年 05 月 10 日 08:17
-- 服务器版本: 5.5.53
-- PHP 版本: 5.4.45

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- 数据库: `bolg`
--

-- --------------------------------------------------------

--
-- 表的结构 `activity`
--

CREATE TABLE IF NOT EXISTS `activity` (
  `id` int(11) NOT NULL COMMENT '商店id',
  `activityname` varchar(50) NOT NULL COMMENT '活动内容说明',
  `activitytype` int(1) NOT NULL COMMENT '（ 满减0 ， 打折1）'
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COMMENT='商家活动表';

--
-- 转存表中的数据 `activity`
--

INSERT INTO `activity` (`id`, `activityname`, `activitytype`) VALUES
(1, '所有食品打七折', 0);

-- --------------------------------------------------------

--
-- 表的结构 `address`
--

CREATE TABLE IF NOT EXISTS `address` (
  `id` int(10) unsigned NOT NULL COMMENT '用户id',
  `useraddress` varchar(100) NOT NULL COMMENT '用户地址',
  `usernum` bigint(11) unsigned NOT NULL COMMENT '用户电话',
  `label` int(1) NOT NULL COMMENT '0：家 1：学校 2：公司  （标签）'
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COMMENT='用户地址表';

--
-- 转存表中的数据 `address`
--

INSERT INTO `address` (`id`, `useraddress`, `usernum`, `label`) VALUES
(1, '广州市海珠区', 11111111111, 1);

-- --------------------------------------------------------

--
-- 表的结构 `business`
--

CREATE TABLE IF NOT EXISTS `business` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '商家id',
  `busname` varchar(20) NOT NULL COMMENT '商家店名',
  `buspow` varchar(32) NOT NULL COMMENT '商家的密码',
  `busaddress` varchar(50) NOT NULL COMMENT '商家地址',
  `busphone` bigint(11) unsigned NOT NULL COMMENT '商家电话',
  `buslogo` varchar(50) NOT NULL COMMENT '商家的图片地址',
  `busstart` int(3) NOT NULL COMMENT '起送价格',
  `busprice` int(2) NOT NULL COMMENT '配送费用',
  `busnum` int(12) NOT NULL COMMENT '店铺的成交次数',
  `busnotice` varchar(100) NOT NULL COMMENT '店铺公告',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4 COMMENT='商家表' AUTO_INCREMENT=4 ;

--
-- 转存表中的数据 `business`
--

INSERT INTO `business` (`id`, `busname`, `buspow`, `busaddress`, `busphone`, `buslogo`, `busstart`, `busprice`, `busnum`, `busnotice`) VALUES
(1, '汉堡王', '202cb962ac59075b964b07152d234b70', '广州叠景路店（23106）', 12345678945, '\\images\\111.jpg', 20, 5, 0, '欢迎光临，用餐高峰期请提前下单，谢谢'),
(2, '', '', '', 2147483647, '', 0, 0, 0, ''),
(3, '', '', '', 2147483647, '', 0, 0, 0, '');

-- --------------------------------------------------------

--
-- 表的结构 `discount`
--

CREATE TABLE IF NOT EXISTS `discount` (
  `id` int(11) NOT NULL COMMENT '商家id',
  `discount` int(11) NOT NULL COMMENT '折扣 0.1~0.9（因为小数要除以10）'
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COMMENT='折扣表';

--
-- 转存表中的数据 `discount`
--

INSERT INTO `discount` (`id`, `discount`) VALUES
(1, 70);

-- --------------------------------------------------------

--
-- 表的结构 `fullsubtraction`
--

CREATE TABLE IF NOT EXISTS `fullsubtraction` (
  `id` int(11) NOT NULL COMMENT '商家id',
  `full` int(11) NOT NULL COMMENT '满多少',
  `subtraction` int(11) NOT NULL COMMENT '减多少'
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COMMENT='满减表';

--
-- 转存表中的数据 `fullsubtraction`
--

INSERT INTO `fullsubtraction` (`id`, `full`, `subtraction`) VALUES
(1, 50, 20);

-- --------------------------------------------------------

--
-- 表的结构 `goods`
--

CREATE TABLE IF NOT EXISTS `goods` (
  `id` int(10) unsigned NOT NULL COMMENT '商品id',
  `goodsname` varchar(20) NOT NULL COMMENT '商品名',
  `goodsprice` int(11) NOT NULL COMMENT '商品价格',
  `goodsnum` int(11) NOT NULL COMMENT '商品库存',
  `goodssrc` varchar(100) NOT NULL COMMENT '图片地址链接'
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COMMENT='商家店铺商品表';

--
-- 转存表中的数据 `goods`
--

INSERT INTO `goods` (`id`, `goodsname`, `goodsprice`, `goodsnum`, `goodssrc`) VALUES
(1, '霸王鸡盒', 36, 1000, '\\images\\123.jpg');

-- --------------------------------------------------------

--
-- 表的结构 `ordernumber`
--

CREATE TABLE IF NOT EXISTS `ordernumber` (
  `useid` int(11) NOT NULL COMMENT '用户id',
  `busid` int(11) NOT NULL COMMENT '店铺id',
  `ordererid` int(11) NOT NULL COMMENT '订单号'
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COMMENT='购物订单号表';

--
-- 转存表中的数据 `ordernumber`
--

INSERT INTO `ordernumber` (`useid`, `busid`, `ordererid`) VALUES
(1, 1, 1);

-- --------------------------------------------------------

--
-- 表的结构 `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '用户名id',
  `usename` varchar(30) NOT NULL COMMENT '用户名（昵称）',
  `usenum` bigint(11) unsigned NOT NULL COMMENT '手机号（登录名）',
  `usepow` varchar(32) NOT NULL COMMENT '用户密码',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4 COMMENT='用户表' AUTO_INCREMENT=12 ;

--
-- 转存表中的数据 `user`
--

INSERT INTO `user` (`id`, `usename`, `usenum`, `usepow`) VALUES
(1, 'alax', 12345678912, '123'),
(2, 'abc', 12345678912, '123'),
(11, 'aaaa', 12345678912, '123');

-- --------------------------------------------------------

--
-- 表的结构 `userorder`
--

CREATE TABLE IF NOT EXISTS `userorder` (
  `id` int(10) unsigned NOT NULL COMMENT '用户id',
  `orderid` int(10) NOT NULL COMMENT '订单号id',
  `ordername` varchar(30) NOT NULL COMMENT '订单名字',
  `orderprice` int(10) NOT NULL COMMENT '订单价钱'
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COMMENT='订单表';

--
-- 转存表中的数据 `userorder`
--

INSERT INTO `userorder` (`id`, `orderid`, `ordername`, `orderprice`) VALUES
(1, 1, '汉堡王（广州叠景路店23106）', 36);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
